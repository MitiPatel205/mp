<?php
if(isset($_POST['About Us']))
{
    
    {
       
        echo "<script> window.location.assign('MPM.html'); </script>";
      

    }


}
?>