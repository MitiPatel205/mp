<?php
if(isset($_POST['HEADACHE']))
{
    
    {
       
        echo "<script> window.location.assign('HEADACHE.html'); </script>";
      

    }


}
?>