<?php
if(isset($_POST['FEVER']))
{
    
    {
       
        echo "<script> window.location.assign('MPM.html'); </script>";
      

    }


}
?>