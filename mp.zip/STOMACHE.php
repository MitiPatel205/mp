<?php
if(isset($_POST['STOMACHE']))
{
    
    {
       
        echo "<script> window.location.assign('MPM.html'); </script>";

    }


}
?>