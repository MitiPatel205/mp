<?php
if(isset($_POST['COUGH']))
{
    
    {
       
        echo "<script> window.location.assign('COUGH.html'); </script>";
      

    }


}
?>